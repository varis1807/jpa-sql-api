package com.example.jpasqlapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaSqlApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
